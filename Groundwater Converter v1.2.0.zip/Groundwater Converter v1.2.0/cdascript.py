while True:
    try:

        #import libraries
        import numpy as np
        import pandas as pd
        import os
        import sys
        from statistics import mode
        import time

        #files for testing without guiscript
        #fileOne = 'inputFiles/CDA Inorganic Detect 07102025.csv'
        #fileTwo = 'inputFiles/CDA Inorganic Nondetect 07102025.csv'
        #extraFile1 = 'inputFiles/CDA Nutrients Detect 07102025.csv'
        #extraFile2 = 'inputFiles/CDA Nutrients Nondetect 07102025.csv'
        #extraFile3 = 'inputFiles/CDA Physical 07102025.csv'

        #import CSVs from guiscript values

        locwellscda = pd.read_csv('locwellscda.csv')

        if fileOne=="0" and fileTwo=="0" and extraFile1=="0" and extraFile2=="0" and extraFile3=="0":
            broken=True
            print("Select the files from the browser")
            break
        elif fileOne=="0" or fileTwo=="0" or extraFile1=="0" or extraFile2=="0" or extraFile3=="0":
            broken=True
            print("Ensure all files are uploaded. All files have been cleared from memory so upload all five files again")
            break

        #one = pd.read_csv(fileOne).fillna(-99.9)
        #two = pd.read_csv(fileTwo).fillna(-99.9)
        #three = pd.read_csv(extraFile1).fillna(-99.9)
        #four = pd.read_csv(extraFile2).fillna(-99.9)
        #five = pd.read_csv(extraFile3).fillna(-99.9)


        files = [fileOne, fileTwo, extraFile1, extraFile2, extraFile3]

        inorgd = inorgnd = NO3d = NO3nd = other = None

        #sort lists
        for f in files:
            df = pd.read_csv(f).fillna(-99.9)
            cols = df.columns.tolist()

            # New CDA long format detection
            if "Analyte Name" in cols:
                analytes = df["Analyte Name"].unique().tolist()
                if any("Nitrate" in a for a in analytes):
                    if "BDLIndicator" in df.columns and df["BDLIndicator"].eq(1).any():
                        NO3nd = f
                    else:
                        NO3d = f
                elif any("Copper" in a or "Cu -" in a for a in analytes):
                    if "BDLIndicator" in df.columns and df["BDLIndicator"].eq(1).any():
                        inorgnd = f
                    else:
                        inorgd = f
                elif any("pH" in a or "Conductance" in a for a in analytes):
                    other = f

            # Old crosstab format detection
            else:
                if "pH (Field)" in cols:
                    other = f
                elif "Nitrate as Nitrogen" in cols:
                    if (df["Nitrate as Nitrogen"] == 0).all():
                        NO3nd = f
                    else:
                        NO3d = f
                elif "Copper" in cols:
                    if (df["Copper"] == 0).all():
                        inorgnd = f
                    else:
                        inorgd = f

        print("Inorganic Detects:", inorgd)
        print("Inorganic Nondetects:", inorgnd)
        print("NO3 Detects:", NO3d)
        print("NO3 Nondetects:", NO3nd)
        print("Other:", other)

        filepaths = [inorgd, inorgnd, NO3d, NO3nd, other]
        
        #set directory for analyte names and WQP examples
        dictFile='analytenames.csv'
        wellData='wellDataCDA.csv'
        WQPnd = 'outputFiles/CrossTabNonDetectsWellsWQP.csv'
        WQPd = 'outputFiles/CrossTabDetectsWellsWQP.csv'

        #import analyte names csv
        analytenames = pd.read_csv(dictFile)

        print("analytes imported")

        # === Helper: Detect and convert if long-format ===
        def load_and_standardize(file_path):
            df = pd.read_csv(file_path).fillna(-99.9)
            cols = df.columns.tolist()

            # New CDA long-format
            if "Analyte Name" in cols and "Result" in cols:
                df = df.copy()
                # Normalize Well ID
                if 'SiteName' in df.columns:
                    df.rename(columns={'SiteName': 'Well ID'}, inplace=True)
                elif 'WellID' in df.columns:
                    df.rename(columns={'WellID': 'Well ID'}, inplace=True)

                # Clean analyte names
                df['Analyte Name'] = df['Analyte Name'].astype(str).str.strip()

                pivot_df = df.pivot_table(
                    index='Well ID',
                    columns='Analyte Name',
                    values='Result',
                    aggfunc='mean'
                ).reset_index()
                pivot_df.columns.name = None

                print(f"Pivoted {file_path}: {pivot_df.shape}")
                
                return pivot_df

            # Old crosstab
            if 'WellID' in df.columns:
                df.rename(columns={'WellID': 'Well ID'}, inplace=True)

            print(f"Loaded crosstab {file_path}: {df.shape}")
            return df

        # === Main function to build CDA outputs ===
        def build_cda_outputs(inorgd, inorgnd, NO3d, NO3nd, other, analytenames_path,
                              wqp_detects_path, wqp_nondetects_path):

            # Load analyte name mapping
            analytenames = pd.read_csv(analytenames_path)
            analyte_map = dict(zip(analytenames['cdaNames'].dropna(), analytenames['newNames'].dropna()))

            # Load and standardize all 5 files
            df_inorgd = load_and_standardize(inorgd)
            df_inorgnd = load_and_standardize(inorgnd)
            df_NO3d = load_and_standardize(NO3d)
            df_NO3nd = load_and_standardize(NO3nd)
            df_other = load_and_standardize(other)

            print("Pivoted Files Loaded")

            # Rename columns based on analyte mapping
            for df in [df_inorgd, df_inorgnd, df_NO3d, df_NO3nd, df_other]:
                df.rename(columns=analyte_map, inplace=True)

            # Merge into detects and nondetects
            detects = pd.concat([df_inorgd, df_NO3d, df_other], axis=0, ignore_index=True).fillna(-99.9)
            nondetects = pd.concat([df_inorgnd, df_NO3nd, df_other], axis=0, ignore_index=True).fillna(-99.9)

            print("Detects & Nondetects sorted")
            
            # Drop duplicate wells
            detects = detects.drop_duplicates(subset=['Well ID'])
            nondetects = nondetects.drop_duplicates(subset=['Well ID'])

            print("Dupes Dropped")

            wellData_df = pd.read_csv(wellData).fillna(-99.9)
    
            if 'WellCode' in wellData_df.columns:
                wellData_df = wellData_df.rename(columns={'WellCode': 'Well ID'})
            if 'LATDDeg' in wellData_df.columns:
                wellData_df = wellData_df.rename(columns={'LATDDeg': 'Latitude'})
            if 'LONDDeg' in wellData_df.columns:
                wellData_df = wellData_df.rename(columns={'LONDDeg': 'Longitude'})

            # Merge wellData into both outputs
            detects = pd.merge(detects, wellData_df[['Well ID', 'Latitude', 'Longitude']], on='Well ID', how='left')
            nondetects = pd.merge(nondetects, wellData_df[['Well ID', 'Latitude', 'Longitude']], on='Well ID', how='left')

            print("Well Data Added")

            new_dfs = []
            for df in [detects, nondetects]:
                df['Well Depth'] = 0
                df['Well Type'] = 'Well'

                # Move the 4 columns to follow Well ID
                cols = df.columns.tolist()
                for col in ['Latitude', 'Longitude', 'Well Depth', 'Well Type']:
                    if col in cols:
                        cols.remove(col)
                insert_at = cols.index('Well ID') + 1
                for idx, col in enumerate(['Latitude', 'Longitude', 'Well Depth', 'Well Type']):
                    cols.insert(insert_at + idx, col)
                df = df[cols]

                # Fill all empty cells with -99.99
                df = df.fillna(-99.99)

                new_dfs.append(df)

            detects, nondetects = new_dfs

            # Align column order to WQP references
            #wqp_detects = pd.read_csv(wqp_detects_path)
            #wqp_nondetects = pd.read_csv(wqp_nondetects_path)
            #detects = detects.reindex(columns=wqp_detects.columns, fill_value=-99.9)
            #nondetects = nondetects.reindex(columns=wqp_nondetects.columns, fill_value=-99.9)

            # === Debug Prints ===
            print("Detects shape:", detects.shape)
            print("Nondetects shape:", nondetects.shape)
            print("Detects preview:")
            print(detects.head())
            print("Nondetects preview:")
            print(nondetects.head())

            # Save outputs
            os.makedirs('outputFiles', exist_ok=True)
            detects.to_csv('outputFiles/CrossTabDetectsWellsCDA.csv', index=False)
            nondetects.to_csv('outputFiles/CrossTabNonDetectsWellsCDA.csv', index=False)

            print("CDA Detects and Nondetects exported successfully.")


        for i in filepaths:
            i=load_and_standardize(i)
            #print(i)

        build_cda_outputs(inorgd, inorgnd, NO3d, NO3nd, other, dictFile,
                              WQPd, WQPnd)
        

    except:
        print("Program failed in CDA conversion")
        broken=True
        break
    broken=False
    break
