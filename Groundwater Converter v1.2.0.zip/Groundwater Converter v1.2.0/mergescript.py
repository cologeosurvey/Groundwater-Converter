## Import useful packages

#import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import sys

##Set up variables

#set counting variables
c0 = 0
c1 = 0

#set folder to inputs for final tables
fol = 'outputFiles\\'

#create empty lists to add all files to
list_of_files = []
list_of_data = []

#create empty lists to add
dw = []
ndw = []
ds = []
nds = []

#create list for final data
finaldata = []

##Import data

#for all files within the selected flder, add file to the list_of files
for root, dirs, files in os.walk(fol):
	for file in files:
		list_of_files.append(os.path.join(root,file))

#for all files found above import data from them
for i in list_of_files:
	list_of_data.append(pd.read_csv(i))

#for all files within the list of files, sort by name
for i in list_of_files:
	if 'TabDetectsWells' in i: #if the name contains tabdetectswells, append it to the detectswells list.
		dw.append(list_of_data[c0])
	if 'TabNonDetectsWells' in i: #if the name contains tabdetects wells, append to the nondetectwells list.
		ndw.append(list_of_data[c0])
	if 'TabDetectsSprings' in i:
		ds.append(list_of_data[c0]) #etc.
	if 'TabNonDetectsSprings' in i:
		nds.append(list_of_data[c0]) #etc.
	c0+=1
c0 = 0

#put named, imported, sorted data in list
data = [dw,ndw,ds,nds]

##Organize data

#homogenize column names
for i in data: #for every list in data
	for j in i: #for every item on every list
		j.columns = ['Identifier',*j.columns[1:]] #rename the first column 'Identifier'
	tempvar = pd.concat(i,ignore_index=True).fillna(-99.9) #set temperary variable to the concatenated list
	finaldata.append(tempvar) #append final list with final data

#finish cleaning up final data
for i in finaldata: #for every list in finaldata
	finaldata[c0] = i[sorted(i.columns)] #sort the columns of that list alphabetically
	idn   ='Identifier' #define important column names
	latn  = 'Latitude'
	longn = 'Longitude'
	wdn   = 'Well Depth'
	wtn   = 'Well Type'
	id = finaldata[c0].pop(idn) #pop important columns to the variable listed
	lat = finaldata[c0].pop(latn)
	long = finaldata[c0].pop(longn)
	wd = finaldata[c0].pop(wdn)
	wt = finaldata[c0].pop(wtn)
	#put variables and names with popped column in a list
	forlist = [wt,wd,long,lat,id]
	fornlist = [wtn,wdn,longn,latn,idn]
	#reorganize data
	for j in forlist: #for every popped column in forlist,
		finaldata[c0].insert(0, fornlist[c1], j) #insert the popped column onto the finaldata list they were taken from.
		c1+=1 #increment counter
	c0+=1 #increment counter
	c1=0 #reset counter
c0=0#reset counter


##Merge Sulfate as S & SO4

#for i in [0,1,2,3]:
	#for j in finaldata[i].loc[:,"SO4_mg_L"]:
		#pass
		#v0=finaldata[i].loc[c0,'SO4_mg_L']
	#v1=finaldata[i].loc[:,'Sulfate as S']
	#if v0 == -99.9:
	#	if v1 > 0:
	#	finaldata[i].loc[:,'SO4_mg_L']=v1

##Remove extra columns

finaldata[2].drop('Well Depth', axis=1, inplace=True)
finaldata[3].drop('Well Depth', axis=1, inplace=True)

##Export data

#save to csv
finaldata[0].to_csv('finaloutput\\CrossTabDetectsWells.csv',index=0)
finaldata[1].to_csv('finaloutput\\CrossTabNonDetectsWells.csv',index=0)
finaldata[2].to_csv('finaloutput\\CrossTabDetectsSprings.csv',index=0)
finaldata[3].to_csv('finaloutput\\CrossTabNonDetectsSprings.csv',index=0)
