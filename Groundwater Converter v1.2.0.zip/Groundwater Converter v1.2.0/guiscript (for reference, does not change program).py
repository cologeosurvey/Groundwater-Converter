## Import useful data

import PySimpleGUI as sg
import os

#set up constants
listBox=['Water Quality Portal','Oil and Gas Commission','Colorado Department of Agriculture'] #options for data analysis. To add another, you must write another script and add an option here
WQPS = 'nondwrscript.py' #location of the WQPS script
COGCC = 'oilgasscript.py' #location of COGCC script
CDA = 'cdascript.py' #location of CDA script
merge = 'mergescript.py' #location of merge script
fileOne="0" #set file values to default 0
fileTwo="0"
extraFile1="0"
extraFile2="0"
extraFile3="0"

## Design gui

#Define the layout
col = [[sg.Text('Folder'), sg.In(size=(25,1), enable_events=True ,key='-FOLDER-'), sg.FolderBrowse()], #Folder browser setup
            [sg.Listbox(values=[], enable_events=True, size=(40,10),key='-FILE LIST-')],[sg.Text('Select Data Source')],[sg.Combo(listBox,default_value='Data Source',enable_events=True,key='-COMBO-')],[sg.Text('Desired County (Necessary for COGCC)')], #Folder selecter setup, listbox setup, and county selecter setup
                             [sg.Input(key='-COUNTY-', size=(19,1))],[sg.Text("Upload Primary Files Here")],[sg.Button('Upload File 1'),sg.Button('Upload File 2')],[sg.Text('Upload Additional CDA Files Here (Run after WQP)')],[sg.Button('CDA File 3'),sg.Button('CDA File 4'),sg.Button('CDA File 5')],[sg.Text("Main Controls")],[sg.Button('Run'),sg.Button('Merge Outputs'), sg.Button('Exit')]] #county setup cont, all button setup
#tell gui to use this as the layout
layout = [[sg.Column(col)]]

## Create gui

#create the window
window = sg.Window('Groundwater Data Converter', layout)
sg.theme('BlueMono')

try:
    #event loop
    while True: #while running (always)
        event, values = window.read() #read the events and values coming from the window
        if event in (None, 'Exit'): #if exit button pressed
            break #break loop
        if event == 'Upload File 1': #if upload button selected
            try:
                fileOne=fileSelected #set file selected in browser to variable for this specific button
                print('File 1 set to ',fileSelected) #print in console what this file is
            except:
                print("Select a file in the browser")
        if event == 'Upload File 2':#if upload button selected
            try:
                fileTwo=fileSelected #set file selected in browser to variable for this specific button
                print('File 2 set to ',fileSelected) #print in console what this file is
            except:
                print("Select a file in the browser")
        if event == 'Run': #if run button selected
            if values['-COMBO-'] == 'Water Quality Portal': #check to see which script should be run
                exec(open(WQPS).read()) #run script
                if broken == False:
                    print("Files processed") #print files processed when done
                    print("Upload Files Reset")
                fileOne="0" #reset files
                fileTwo="0"
                extraFile1="0"
                extraFile2="0"
                extraFile3="0"
            elif values['-COMBO-'] == 'Oil and Gas Commission': #check to see which script should be run
                county = values['-COUNTY-'] #set county variable equal to written in prompt '-county-'
                if fileOne!="0" or fileTwo!="0" and county !="":
                    print('Selected county is "'+county+'"') #print what county is for clarity
                exec(open(COGCC).read()) #run script
                if broken == False:
                    print('Files processed') #print files processed when done
                    print("Upload Files Reset")
                fileOne="0" #reset files
                fileTwo="0"
                extraFile1="0"
                extraFile2="0"
                extraFile3="0"

            elif values['-COMBO-'] == 'Colorado Department of Agriculture': #check to see which script should be run
                exec(open(CDA).read()) #run script
                if broken==False:
                    print('Files processed') #print files processed when done
                    print("Upload Files Reset")
                fileOne="0" #reset files
                fileTwo="0"
                extraFile1="0"
                extraFile2="0"
                extraFile3="0"
            else:
                print("Select a data processing type") #if one forgots to select processing type, remind

        if event == 'CDA File 3': #if upload button selected
            try:
                extraFile1 = fileSelected #set file selected in browswer to variable for this specific button
                print('CDA File 3 set to ',fileSelected) #print in console what this file is
            except:
                print("Select a file in the browser")
        if event == 'CDA File 4': #if upload button selected
            try:
                extraFile2 = fileSelected #set file selected in browswer to variable for this specific button
                print('CDA File 4 set to ',fileSelected) #print in console what this file is
            except:
                print("Select a file in the browser")
        if event == 'CDA File 5': #if upload button selected
            try:
                extraFile3 = fileSelected #set file selected in browswer to variable for this specific button
                print('CDA File 5 set to ',fileSelected) #print in console what this file is
            except:
                print("Select a file in the browser")
        if event == 'Merge Outputs': #if merge button selected
            try:
                exec(open(merge).read()) #run the merge script
                print('Files merged successfully') #when completed, print as such
            except:
                print('Merge failed, ensure files are located in "outputFiles"')

        if event == '-FOLDER-': #if browse button selected
            folder = values['-FOLDER-'] #set folder variable to the value selected in the file browser
            try: #try to get a list of files from selected folder
                file_list = os.listdir(folder)
            except: #if this does not work, reset folder to blank, try gain
                file_list = []

            fnames = [f for f in file_list if os.path.isfile( #for every file in the file list
                os.path.join(folder, f)) and f.lower().endswith((".csv",".xlsx",".xls"))] #check to see if csv or excel file
            window['-FILE LIST-'].update(fnames) #set file list on equal to list generated from fnames
        elif event == '-FILE LIST-': #if a file is chosen from this list
            try: #try to set it equal to file seleced
                fileSelected=os.path.join(values['-FOLDER-'], values['-FILE LIST-'][0])
            except: #if it does not work ignore this, try again
                pass

    ## Close when done
    window.close()
except:
    print('Converter failed due to unknown error. Please restart the program.')
