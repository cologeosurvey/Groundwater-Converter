    ## Import useful data

while True:

    #import libraries
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import os
    import sys
    from statistics import mode

    #files for testing without guiscript
    #fileOne = 'inputFiles/CDA/inorgdetects.csv'
    #fileTwo = 'inputFiles/CDA/actualnondetectsinorgct.csv'
    #extraFile1 = 'inputFiles/CDA/NO3detects.csv'
    #extraFile2 = 'inputFiles/CDA/actualnondetectsno3ct.csv'
    #extraFile3 = 'inputFiles/CDA/otherdata.csv'

    #import CSVs from guiscript values

    locwellscda = pd.read_csv('locwellscda.csv')

    if fileOne=="0" and fileTwo=="0" and extraFile1=="0" and extraFile2=="0" and extraFile3=="0":
        broken=True
        print("Select the files from the browser")
        break
    elif fileOne=="0" or fileTwo=="0" or extraFile1=="0" or extraFile2=="0" or extraFile3=="0":
        broken=True
        print("Ensure all files are uploaded. All files have been cleared from memory so upload all five files again")
        break

    try:
        one = pd.read_csv(fileOne).fillna(-99.9)
        two = pd.read_csv(fileTwo).fillna(-99.9)
        three = pd.read_csv(extraFile1).fillna(-99.9)
        four = pd.read_csv(extraFile2).fillna(-99.9)
        five = pd.read_csv(extraFile3).fillna(-99.9)
    except:
        broken=True
        break
    #create a list of lists in order to figure out which is which
    lists=(one,two,three,four,five)

    #set up counters
    c0 = 0 #counter 1
    c1 = 0 #counter 2

    #sort lists
    for i in lists: #for all in lists
        for j in i.columns.tolist(): #for every column header in every item in lists
            if j == 'pH (Field)': #if it contains pH field
                other = i #set that list to be other
            elif j == 'Nitrate as Nitrogen': #if it contains NO3 as N,
                for k in i['Nitrate as Nitrogen']: #for every value in NO3 as N
                    if k == 0: #if value = 0
                        NO3nd = i #set that list to be NO3 as N non-detects
                        break #leave for loop
                    elif k != 0 and k != -99.9: #if that value is anything else
                        NO3d = i #set that list to be NO3 as N detects
                        break #leave for loop
            elif j == 'Copper': #if it contains Copper
                for k in i['Copper']: #for all values in copper
                    if k == 0: # if 0 is contained in this set
                        inorgnd = i #set the list to inorganic non-detects
                        break #leave for loop
                    elif k !=0 and k != -99.9:  #if that sum is anything else
                        inorgd = i #set the list to be inorganic detects
                        break #leave for loop
            c0+=1
        c0=0
    #set directory for analyte names
    dictFile='analytenames.csv'

    #import analyte names csv
    analytenames = pd.read_csv(dictFile)


    ## Format useful data

    inorgnd.rename(columns = {'WellID':'Well ID'}, inplace = True)
    NO3nd.rename(columns = {'WellID':'Well ID'}, inplace = True)


    #put analyte names in a dictonary to be used to unify names
    oldNames = analytenames['cdaNames'].tolist()
    newNames = analytenames['newNames'].tolist()
    nameDict = dict(zip(oldNames,newNames))

    ##take data from newly made dataframes and put them in lists
    #this is specifically for other
    wIDother = other['Well ID'].tolist()
    pH = other['pH (Field)'].fillna(-99.9).tolist()
    sC = other['Specific Conductance (Field)'].fillna(-99.9).tolist()
    H2Odepth = other['Static Water Level'].fillna(-99.9).tolist()
    waterTemp = other['Water Temperature (Surface)'].fillna(-99.9).tolist()
    TDS = other['Total Dissolved Solids (Field)'].fillna(-99.9).tolist()

    #this is specifically for NO3 detects
    wIDNO3d = NO3d['Well ID'].tolist()
    nasNO3d = NO3d['Nitrate as Nitrogen'].fillna(-99.9).tolist()

    #this is specifically for NO3 non detects
    wIDNO3nd = NO3nd['Well ID'].tolist()
    nasNO3nd = NO3nd['Nitrate as Nitrogen'].fillna(-99.9).tolist()

    #zip together lists in order to put in dataframe again with modified data
    olist = zip(wIDother,TDS,H2Odepth,waterTemp,pH,sC)
    NO3listd = zip(wIDNO3d,nasNO3d)
    NO3listnd = zip(wIDNO3nd,nasNO3nd)

    #put in dataframe, name columns
    otherdata = pd.DataFrame(olist,columns=['Well ID','TDS_mg_L','H20depthBGS_ft','Temp_C','pH_field','SpC_uS_cm'])
    NO3detects = pd.DataFrame(NO3listd,columns=['Well ID','NO3_as_N_mg_L'])
    NO3nondetects = pd.DataFrame(NO3listnd,columns=['Well ID','NO3_as_N_mg_L'])

    #merge qll 3 detects files
    detectsi = pd.concat([inorgd,otherdata]).fillna(-99.9)
    detectsb = pd.concat([detectsi,NO3detects]).fillna(-99.9)

    #merge all 3 nondetect files
    nondetectsi = pd.concat([inorgnd,otherdata]).fillna(-99.9)

    #nondetectsb = pd.merge(nondetectsi,NO3nondetects).fillna(-99.9)
    nondetectsb=pd.concat([nondetectsi,NO3nondetects]).fillna(-99.9)

    ##create list of unecessary components so that they can be removed

    #add in one initial datset for both detects and nondetects, then put them in list
    dremove = [detectsb]
    ndremove = [nondetectsb]
    dndlist = (dremove,ndremove)

    #for all items in dndlist (deremove and ndremove)
    for i in dndlist:
        for j in i[0].columns.tolist(): #for each item within the columns of that list (this will be [detectsb] and [nondetectsb], these are the lists created earlier)
            if j == 'Sample ID':   #if any of the below columns are on the nondetect or detect list, add them to the end of the list of [detectsb] and [nondetectsb]. i.e. [detectsb,'Sample ID']
                i.append('Sample ID')
            if j == 'County':
                i.append('County')
            if j == 'Watershed':
                i.append('Watershed')
            if j == 'Sample Party':
                i.append('Sample Party')
            if j == 'Date':
                i.append('Date')
            if j == 'Units':
                i.append('Units')
            if j == 'Dissolved Organic Carbon':
                i.append('Dissolved Organic Carbon')
            if j == 'Carbon':
                i.append('Carbon')
        del(i[0]) #remove the initial [detects] and [nondetects] variables from the list, should output just the appended categories that must be removed: ['Sample ID','County',etc.],['Sample ID','County',etc]

    #drop uncessesary information from the detects and nondetects
    detects = detectsb.drop(dndlist[0],axis=1)
    nondetects = nondetectsb.drop(dndlist[1],axis=1)


    #rename the analytes using the namedict
    detects.rename(columns=nameDict,inplace=True)
    nondetects.rename(columns=nameDict,inplace=True)

    #create final detects file by dropping all duplicate IDs
    detectsf = detects.drop_duplicates(['Well ID'])
    nondetectsf = nondetects.drop_duplicates(['Well ID'])

    outputs=[detectsf,nondetectsf]

    for t in outputs:
        for i in t.columns.tolist(): #for all columns
            try: #try to
                lnew=[] 
                l=t[i].tolist() #create a list of all values in a column
                for j in l:
                    if j == -99.9:
                        lnew.append(-100)
                    else:
                        lnew.append(0)
                avg=sum(lnew)/len(lnew) #take the average of those values
                if avg==-100: #find if the average is 
                    del t[i]
            except:
                pass

        ## Replace 0s with common detection limits

    #import data from the nondetects of the water quality portal
    wqpW = pd.read_csv('outputFiles/CrossTabNonDetectsWellsWQP.csv')
    wqpS = pd.read_csv('outputFiles/CrossTabNonDetectsSpringsWQP.csv')

    #merge springs and wells
    wqp = pd.concat([wqpW,wqpS],axis=0,).reset_index()
    #remove index
    del(wqp['index'])

    #create empty lists to be appended to below, these will be used for the mode values and names of the detection limits we wish to import
    cmodes=[]
    cnames=[]


    #for every column in the water quality portal, ignoring all -99.9s, find the most common value of the analyte
    for i in wqp.columns.tolist(): #for every column in the water quality portal
        l=wqp.iloc[:,c0].tolist() #set l to be the list of values in that column
        lt=[]
        for j in l:
            if j ==-99.9:
                pass
            elif type(j)==float:
                if j <=0 or j>=0:
                    lt.append(j)
        if lt == []: #if lt is empty (all values are -99.9)
            if i in nondetectsf.columns.tolist():
                cmodes.append(0)#set detection limit to 0
                cnames.append(i) #and name to the analyte name
        else: #if detection limit is nonzero
            if i in nondetectsf.columns.tolist():
                cmodes.append(mode(lt)) #set detection limit to node
                cnames.append(i) #set name to analyte name
        c0+=1 #increment counter
    c0=0 #reset counter
    #remove the first 6 entries from the modes and names, as these are not analtes but rather information about the well site that we do not need

    coutputs = [] #make an empty list for final outputs
    lcolumns = nondetectsf.columns.tolist() #take all column names from the nondetectsf columns, enter them into a list
    ccnames = [] #empty list for complete cnames
    ccmodes = [] #empty list for complete cmodes

    nondetectsf = nondetectsf.sort_index(axis=1) #sort nondetects alphabetically
    nondetectsf.insert(0,"Well ID",nondetectsf.pop("Well ID")) #move Well ID to the front

    cnamesordered=sorted(cnames) #sort cnames alphabetically
    cmodesordered=[x for _,x in sorted(zip(cnames,cmodes))] #sort cmodes based on cnames alphabetically

    for i in cnamesordered: #for every value of cnames
        nondetectsf[i]=nondetectsf[i].replace(0,cmodesordered[c0]) #replace the old columns with 0s with the version taking the most common detection limit from the WQP
        c0+=1 #increment counter
    c0=0 #reset counter

        #add in location of wells
    nondetectsll=pd.merge(nondetectsf,locwellscda)
    detectsll=pd.merge(detectsf,locwellscda)

    locs=[nondetectsll.pop('Latitude'),nondetectsll.pop('Longitude')]
    nondetectsll.insert(1,'Longitude',locs[1])
    nondetectsll.insert(1,'Latitude',locs[0])
    locs=[detectsll.pop('Latitude'),detectsll.pop('Longitude')]
    detectsll.insert(1,'Longitude',locs[1])
    detectsll.insert(1,'Latitude',locs[0])
        ## export files

    detectsll.to_csv(r'outputFiles\CrossTabDetectsWellsCDA.csv',index=False) #to csv
    nondetectsll.to_csv(r'outputFiles\CrossTabNonDetectsWellsCDA.csv',index=False) #to csv
    broken=False
    break
