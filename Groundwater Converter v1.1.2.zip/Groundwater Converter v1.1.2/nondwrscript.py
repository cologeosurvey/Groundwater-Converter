    ## Import all used data

while True:

    #Import useful libraries
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import os
    import sys
    import time

    def rearrange_columns(source_csv, reference_csv, output_csv):
        # Load the CSV files
        source_df = pd.read_csv(source_csv)
        reference_df = pd.read_csv(reference_csv)

        # Get the column order from the reference CSV
        reference_columns = reference_df.columns.tolist()

        # Reorder columns based on the reference, moving unmatched columns to the end
        ordered_columns = [col for col in reference_columns if col in source_df.columns]
        unmatched_columns = [col for col in source_df.columns if col not in reference_columns]
        final_columns = ordered_columns + unmatched_columns

        # Reorder the source DataFrame
        rearranged_df = source_df[final_columns]

        # Save the rearranged DataFrame to a new CSV
        rearranged_df.to_csv(output_csv, index=False)

    rref_csv = 'resultphyschem_SLV_5counties_241104.csv'
    sref_csv = 'station_SLV_5counties_241104.csv'

    #testing imports independant of guiscript
    #fileOne=r'C:\Users\decla\Documents\PythonGroundWater\updatedUpdatedOutput\inputFiles\WQP\resultphyschem.csv'
    #fileTwo=r'C:\Users\decla\Documents\PythonGroundWater\updatedUpdatedOutput\inputFiles\WQP\station.csv'

    #determine which file from guiscript is results
    if 'result' in fileOne:
        resultsFile = fileOne
        stationFile = fileTwo

        rearrange_columns(fileOne, rref_csv, resultsFile)
        rearrange_columns(fileTwo, sref_csv, stationFile)
        
    elif 'result' in fileTwo:
        resultsFile = fileTwo
        stationFile = fileOne

        rearrange_columns(fileOne, sref_csv, stationFile)
        rearrange_columns(fileTwo, rref_csv, resultsFile)
        
    elif fileOne=="0" and fileTwo=="0":
        print('Select the files from the browser')
        broken=True
        break
    else:
        print('Please make sure the result file says "result" somewhere')
        broken=True
        break

    print("Files initialized")

    #bring in the analyte name list
    dictFile='analytenames.csv'
    removeFile='analytenamesremoved.csv'

    #define global variables (these will be used for counters later on)
    c0 = 0 #counter 1
    c1 = 0 #counter 2

    #Using pandas, import all files as dataframe
    dfchem = pd.read_csv (resultsFile,low_memory=False)
    dfstat = pd.read_csv (stationFile)
    analytenames = pd.read_csv(dictFile)
    removenames = pd.read_csv(removeFile)

    print("files imported")

    ## Format all used data

    #Create lists for the Water quality portal names and the new, standardized names -- create dicionary using them
    oldNames = analytenames['wqpNames'].tolist()
    newNames = analytenames['newNames'].tolist()
    nameDict = dict(zip(oldNames,newNames))

    #Create lists fro the removable names
    removables = removenames['wqpNames'].tolist()

    #Draw from Results
    MonLocID = dfchem['MonitoringLocationIdentifier'].tolist() #put MonitoringLocationIdentifier in list
    CN = dfchem['CharacteristicName'].replace(nameDict).tolist() #put CharacteristicName in list
    RMV = dfchem['ResultMeasureValue'].replace(['0'],-50).fillna(0).tolist() #put ResultMeasureValue in list, fill 0s with -50 (this is to preserve actual 0 detects)
    RMRMUC = dfchem['ResultMeasure/MeasureUnitCode'].tolist() #etc.
    ASD = dfchem['ActivityStartDate'].tolist()
    DL = dfchem['DetectionQuantitationLimitMeasure/MeasureValue'].fillna(0).tolist()
    DLU = dfchem['DetectionQuantitationLimitMeasure/MeasureUnitCode'].tolist()
    U = [None] * len(MonLocID) #create a list (as long as the MonLocID list) and fill it with the None value.

    print("Results drawn")

    #Draw From Station
    MonLocIDStat = dfstat['MonitoringLocationIdentifier'].tolist() #put the MonitoringLocationIdentifier from station in list
    Lat = dfstat['LatitudeMeasure'].tolist() #etc.
    Long = dfstat['LongitudeMeasure'].tolist()
    Form = dfstat['FormationTypeText'].tolist()
    WDV = dfstat['WellDepthMeasure/MeasureValue'].fillna(0).tolist() #fill blanks with 0
    WT = dfstat['MonitoringLocationTypeName'].tolist()

    print("Station drawn")

    #Remove redundencies in data WellType
    for i in RMV: #for every value of RMV
        try: #try to convert into a float using counter value
            RMV[c1]=float(i)
        except: #if this is not possible, set the value to -80.2 (use this to see if you're missing data, there should be no -80.2s)
            RMV[c1]=-80.2
        c1+=1 #add one to the counter
    c1 = 0 #reset counter for future use

    #Check units
    for i in RMRMUC: #for every value of Result units
        if i == 'ug/l': #if the units are micrograms per liter
            RMRMUC[c1] = 'mg/l' #convert name to milligrams per liter
            RMV[c1] = RMV[c1] / 1000 # convert value to milligrams per liter
        if i == 'mg/l asNO3': #if units are per NO3
            RMRMUC[c1] = 'mg/l as N' #change name to per N
            RMV[c1] = RMV[c1] / 4.43 #change value to per N
        c1 += 1 #add one to counter
    c1 = 0 #reset counter

    print("Units Converted")

    #Check if Nitrate is by N or NO3

        #if it is by NO3, divide by 4.43

    for i in DLU: #for every value in detection limit units
        if i == 'ug/l': #if the units are micrograms per liter
            DLU[c1] = 'mg/l' #convert name to milligrams per liter
            DL[c1] = float(DL[c1]) / 1000 # convert value to milligrams per lit
 
        c1 += 1 #add one to counter
    c1 = 0 #reset counter

    print("NO3 converted")
        
    for i in RMV: #for every value in ResultMeasureValue
        if i == 0: #if value is reported as zero
            RMV[c1] = DL[c1] #set that zero value as the detection limit of the same analyte
            U[c1] = 'U' #fill in U (for undetected) on the list we created above, prepping for splitting detects and non detects
        elif i == -50:
            RMV[c1] = 0
            U[c1] = 'U'
        c1 += 1 #increment counter
    c1 = 0 #reset counter


    print("0s removed")

    ## Split Detects/NonDetects

    #Put respective results/station files in a list in order to convert to dataframe to sort and remove duplicates
    liszt0 = zip(MonLocID,CN,RMV,RMRMUC,ASD,DL,DLU,U)
    liszt1 = zip(MonLocIDStat,Lat,Long,WDV,WT)

    print("Results and Station Files Listed")

    #manipulate data to be useful
    results = pd.DataFrame(liszt0, columns = ['MonLocID','Analyte','ResultValue','ResultUnits','DatesRecorded','DetectionLimit','DetectionLimitUnits','Detected?']) #turn list into a pandas dataframe in order to crosstab and split data
    station = pd.DataFrame(liszt1, columns = ['MonLocID','Latitude','Longitude','Well Depth','Well Type']) #turn list into a pandas dataframe in order to crosstab and split data

    print("Data Manipulated")

    #split detects/nondetects using U value from earlier for loop
    detects = results[(results['Detected?'] != 'U')]
    nondetects = results[(results['Detected?'] == 'U')]

    print("Detects and Nondetects Split")

    #remove duplicates from detects and non-detects by sorting by ascending or descending result value then dropping the duplicates after the first one of its type (this takes either the max or min depending on ascending or descending.)
    detects = detects.sort_values('ResultValue',ascending=False).drop_duplicates(['MonLocID','Analyte']).sort_index()
    print("Detect Duplicates Removed")
    time.sleep(1)
    print(nondetects)
    print(nondetects[['MonLocID', 'Analyte', 'ResultValue', 'DatesRecorded']])
    time.sleep(8)

    nondetects.columns = nondetects.columns.str.strip()
    nondetects['DetectionLimit'] = pd.to_numeric(nondetects['DetectionLimit'], errors='coerce')
    nondetects = nondetects.dropna(subset=['DetectionLimit'])
    nondetects = nondetects.sort_values('DetectionLimit', ascending=True)
    nondetects = nondetects.drop_duplicates(['MonLocID', 'Analyte'])
    nondetects = nondetects.sort_index()
    #nondetects = nondetects.sort_values('ResultValue',ascending=True).drop_duplicates(['MonLocID','Analyte']).sort_index()

    print("Duplicates Removed")

    #remove duplicates from nondetects using detects
    for i in nondetects['ResultValue']: #for all values of resultvalue
        aname=nondetects.iloc[c1,2] #record the name of the assosiated analyte
        for j in detects['Analyte']: #for all analytes in detects
            if j==aname and detects.iloc[c0,3]!=-99.9: #if the analyte name in detects is the same as the name in nondetects, check to see if there is a value for that analyte
                nondetects.iloc[c1,3]=-99.9 #if there is replace the nondetect with -99.9, if there isn't, pass.
            c0+=1 #append c0
        c1+=1 #append c1
    c1=0 #reset counters
    c0=0

    print("Unused nondetects removed")
    time.sleep(1)

    ## Crosstab

    #crosstab data, fill in holes with -99.9, reset index
    CTd=pd.crosstab(detects.MonLocID,detects.Analyte,detects.ResultValue,aggfunc = 'max').fillna(-99.9).reset_index()
    CTnd=pd.crosstab(nondetects.MonLocID,nondetects.Analyte,nondetects.ResultValue,aggfunc = 'max').fillna(-99.9).reset_index()

    #Merge station with crosstabbed data
    CTd=station.merge(CTd)
    CTnd=station.merge(CTnd)


    #Split wells and springs
    CTDW = CTd[(CTd['Well Type'] == "Well")] #using the well type attribute, create a new variable for each well/spring, nondetect/detect dataset
    CTDS = CTd[(CTd['Well Type'] == "Spring")]
    CTNDW = CTnd[(CTnd['Well Type'] == "Well")]
    CTNDS = CTnd[(CTnd['Well Type'] == "Spring")]

    outputs=[CTDW,CTDS,CTNDW,CTNDS]

    #remove columns with no values
    for t in outputs:
        for i in t.columns.tolist(): #for all columns
            try: #try to
                lnew=[] 
                l=t[i].tolist() #create a list of all values in a column
                for j in l:
                    if j == -99.9:
                        lnew.append(-100)
                    else:
                        lnew.append(0)
                avg=sum(lnew)/len(lnew) #take the average of those values
                if avg==-100: #find if the average is 
                    del t[i]
                elif i=='Sulfate as S':
                    t[i]=t[i]*3
                    #for k in t[i]:
                    #    if k < 0:
                    #        t[i[c0]] = -99.9
                    #    c0+=1
                    #c0 = 0
                for l in removables:
                    if i==l:
                        del t[i]
                #elif i=='Sodium, percent total cations': #remove any unwanted columns
                #    del t[i]
                #elif i=='Organic Nitrogen':
                #    del t[i]
                #elif i=='Silica':
                #    del t[i]
                #elif i=='Acidity, (H+)':
                #    del t[i]
                #elif i=='Barometric pressure':
                #    del t[i]
                #elif i=='Flow rate':
                #    del t[i]
                #elif i=='Drawdown level':
                #    del t[i]
                #elif i=='Temperature, air, deg C':
                #    del t[i]
                #elif i=='Flow rate, instantaneous':
                #    del t[i]
                #elif i=='General observation (text)':
                #    del t[i]
                #elif i=='Sodium adsorption ratio [(Na)/(sq root of 1/2 Ca + Mg)]':
                #    del t[i]
                #elif i=='Stream flow, instantaneous':
                #    del t[i]
                #elif i=='Stream flow, mean. daily':
                #    del t[i]
                #elif i=='Turbidity':
                #    del t[i]
                #elif i=='Turbidity severity (choice list)':
                #    del t[i]
                
            except:
                pass

    for t in [CTDW,CTDS]:
        if 'SO4_mg_L' and 'Sulfate as S' in t.columns:
            mask = (t['SO4_mg_L'] < 0) & (t['Sulfate as S'] > 0)
            t.loc[mask, 'SO4_mg_L'] = t.loc[mask, 'Sulfate as S']
            del t['Sulfate as S']
    for t in [CTNDW,CTNDS]:
        if 'Sulfate as S' in t.columns:
            del t['Sulfate as S']
        #for i in t['SO4_mg_L']:
        #    if i < 0:
        #        if t.loc[c0,'Sulfate as S']>0:
        #            t.loc[c0,'SO4_mg_L']=t.loc[c0,'Sulfate as S']

        #    c0+=1
        #c0=0

    ## Output data

    #Put in csv using pandas
    CTDW.to_csv(r'outputFiles\CrossTabDetectsWellsWQP.csv',index=False) #export to CSV, remove index in order to remove bloated data.
    CTDS.to_csv(r'outputFiles\CrossTabDetectsSpringsWQP.csv',index=False)
    CTNDW.to_csv(r'outputFiles\CrossTabNonDetectsWellsWQP.csv',index=False)
    CTNDS.to_csv(r'outputFiles\CrossTabNonDetectsSpringsWQP.csv',index=False)
    broken=False
    break
