    ## Import all data

while True:

    #import useful libraries
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import os
    import sys
    import subprocess

    #set the selected file from guiscript equal to file variable in this script
    if fileOne != "0" and county !="":
        file=fileOne
    elif fileTwo != "0" and county !="":
        file=fileTwo
    elif fileTwo =="0" and fileOne == "0":
        print("Please select a file")
        broken=True
        break
    elif county =="":
        print("Please choose a county")
        broken=True
        break
    #testing files, independant of guiscript
    #county = 'El Paso'
    county=county.strip().upper()
    #file = r'C:\Users\decla\Documents\PythonGroundWater\inputFiles\BasicQuery.csv'

    #import analyte name list
    dictFile='analytenames.csv'

    #set up counter variable
    c1 = 0

    #import data into python from files
    df = pd.read_csv (file, encoding="cp1252")
    analytenames = pd.read_csv(dictFile)

    ## Format imported data

    #create dictionary out of newNames and cogccNames
    oldNames = analytenames['cogccNames'].tolist()
    newNames = analytenames['newNames'].tolist()
    nameDict = dict(zip(oldNames,newNames))

    #Create lists out of columns of daraframe
    FacID = df['FacilityID'].tolist()
    Lat = df['Latitude83'].tolist()
    Long = df['Longitude83'].tolist()
    Date = df['Sample Date'].tolist()
    Mat = df['Matrix'].tolist()
    CN = df['ParamDescription'].replace(nameDict).tolist() #replace these imported parameter names with the updated name list
    RV = df['ResultValue'].replace(['0'],-50).fillna(0).tolist() #Replace all actual 0s with -50 as a placeholder, then fill remaining holes with 0
    U = df['Qualifier'].tolist()
    RU = df['Units'].tolist()
    DL = df['DetectionLimit'].tolist()
    Cty = df['County'].tolist()
    Type = df['Facility Type'].tolist()
    WD = df['WellDepth'].fillna(0).tolist() #fill blanks with 0

    #Check Units

    #convert all RV into float for manipulation
    for i in RV: #for every value in result value
        try: #try to convert it into a float
            RV[c1]=float(i)
        except: #if this fails, replace the value with the placeholder -80.2 used for error detection
            RV[c1]=-80.2
        c1+=1 #increment counter
    c1 = 0 #reset counter

    #unify all units
    for i in RU: #for every unit in RU
        if i == 'ug/L': #if it is equal to ug/L
            RU[c1] = 'mg/L' #make it mg/L
            RV[c1] = RV[c1] / 1000 #convert the value into mg/L
            DL[c1] = DL[c1] / 1000 #convert the detection limit into mg/L
        c1 += 1 #increment counter
    c1 = 0 #reset counter

    #fix the iron issues
    for i in CN:#for all characteristic names
        if i == 'Febad' and CN[c1-1] != 'Fe_mg_L' and CN[c1+1] != 'Fe_mg_L': #if iron is the lower quality detection (Febad) and the detection above and below are anything other than the high quality iron (Fe_mg_L)
            CN[c1] = 'Fe_mg_L' #set the CharacteristicName to Fe_mg_L
        c1 += 1 #increment counter
    c1 = 0 #reset counter

    #fill empty non-detects with detection limit
    for i in RV: #for all of RV
        if i == 0: #If the value is equal to 0
            RV[c1] = DL[c1] #set the value to the detection limit
            U[c1] = 'U' #mark the row as undetected
        elif i==-50: #if the value is -50 (from our original conversion)
            RV[c1] = 0 #reset the value back to 0
            U[c1] = 'U' #mark as undetected
        c1 += 1 #increment counter
    c1 = 0 #reset counter

    #unify case and spaces in cty
    for i in Cty: #for all in Cty
        Cty[c1]=Cty[c1].strip().upper() #remove extra spaces, capitlize all letters
        c1+=1 #increment counter
    c1=0 #reset counter

    ## Split Detects/NonDetects

    #put necessary lists into a zip
    liszt0 = zip(FacID,Cty,Mat,CN,RV,RU,Date,DL,U)
    liszt1 = zip(FacID,Lat,Long,WD,Type)

    #convert that zipped data into dataframe
    data = pd.DataFrame(liszt0, columns = ['FacilityID','County','Matrix', 'Analyte', 'Result','Result Unit','Date Recorded','Detection Limit','Detected?'])
    locdata = pd.DataFrame(liszt1, columns=['FacilityID','Latitude','Longitude','Well Depth','Well Type'])

    #manipulate data to be usable
    ngdata = data[(data['Matrix'] == 'WATER')] #filter out data that isn't water quality
    ncdata = ngdata[(ngdata['County']==county)] #filter our counties that are not of interest
    resdata = ncdata[['FacilityID','Analyte','Result','Result Unit','Date Recorded','Detection Limit','Detected?']] #remove fields that are no longer necessary

    #split actual data
    detects = resdata[(resdata['Detected?'] != 'U')]
    nondetects = resdata[(resdata['Detected?'] == 'U')]

    #remove duplicates from detects and non-detects by sorting by ascending or descending result value then dropping the duplicates after the first one of its type (this takes either the max or min depending on ascending or descending.)
    detects = detects.sort_values('Result',ascending=False).drop_duplicates(['FacilityID',"Analyte"]).sort_index()
    nondetects = nondetects.sort_values('Result',ascending=True).drop_duplicates(['FacilityID',"Analyte"]).sort_index()

    #filter data so that only data from analyenames csv are included in our final output. If you want data to be added to the final output, add it to analyte names, specifically the cogccNames column!
    detectsc=detects[detects['Analyte'].isin(newNames)]
    nondetectsc=nondetects[nondetects['Analyte'].isin(newNames)]

    ## Crosstab data

    #crosstab data, fill holes with -99.9, reset index
    CTd=pd.crosstab(detectsc.FacilityID,detectsc.Analyte,detectsc.Result,aggfunc = 'max').fillna(-99.9).reset_index()
    CTnd=pd.crosstab(nondetectsc.FacilityID,nondetectsc.Analyte,nondetectsc.Result,aggfunc = 'min').fillna(-99.9).reset_index()

    #merge location data with crosstabbed data, get rid of duplicates
    CTd=locdata.merge(CTd).drop_duplicates(['FacilityID'])
    CTnd=locdata.merge(CTnd).drop_duplicates(['FacilityID'])

    CTDS  = CTd
    CTNDS = CTnd
    CTDW  = CTd
    CTNDW = CTnd

    CTDS  = CTDS[(CTDS['Well Type'].ne("Creek"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("River"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Ditch"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Pond"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Surface Water"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Tank"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Cistern"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Commercial"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Domestic Well"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Groundwater"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Ground Water"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Monitoring Well"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Municipal"))]
    CTDS  = CTDS[(CTDS['Well Type'].ne("Stock or  Irrigation"))]

    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Creek"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("River"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Ditch"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Pond"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Surface Water"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Tank"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Cistern"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Commercial"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Domestic Well"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Groundwater"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Ground Water"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Monitoring Well"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Municipal"))]
    CTNDS = CTNDS[(CTNDS['Well Type'].ne("Stock or  Irrigation"))]

    CTDW  = CTDW[(CTDW['Well Type'].ne("Creek"))]
    CTDW  = CTDW[(CTDW['Well Type'].ne("River"))]
    CTDW  = CTDW[(CTDW['Well Type'].ne("Ditch"))]
    CTDW  = CTDW[(CTDW['Well Type'].ne("Pond"))]
    CTDW  = CTDW[(CTDW['Well Type'].ne("Surface Water"))]
    CTDW  = CTDW[(CTDW['Well Type'].ne("Tank"))]
    CTDW  = CTDW[(CTDW['Well Type'].ne("Spring"))]
    CTDW  = CTDW[(CTDW['Well Type'].ne("Seep"))]

    CTNDW = CTNDW[(CTNDW['Well Type'].ne("Creek"))]
    CTNDW = CTNDW[(CTNDW['Well Type'].ne("River"))]
    CTNDW = CTNDW[(CTNDW['Well Type'].ne("Ditch"))]
    CTNDW = CTNDW[(CTNDW['Well Type'].ne("Pond"))]
    CTNDW = CTNDW[(CTNDW['Well Type'].ne("Surface Water"))]
    CTNDW = CTNDW[(CTNDW['Well Type'].ne("Tank"))]
    CTNDW = CTNDW[(CTNDW['Well Type'].ne("Spring"))]
    CTNDW = CTNDW[(CTNDW['Well Type'].ne("Seep"))]

    #split data into wells and springs by using the .ne (anything but) command to remove the incorrect well types from the intended table
    #CTDW = CTd[(CTd['Well Type'].ne("Spring"))]#.ne("Seep").ne("Cistern").ne("Creek").ne("Ditch").ne("Pond").ne("River").ne("Surface Water").ne("Tank"))]
    #CTDS = CTd[(CTd['Well Type'].ne("Commercial"))]#.ne("Domestic Well").ne("Ground Water").ne("Groundwater").ne("Irrigation").ne("Monitoring Well").ne("Municipal").ne("Stock or  Irrigation").ne("Cistern").ne("Creek").ne("Ditch").ne("Pond").ne("River").ne("Surface Water").ne("Tank"))]
    #CTNDW = CTnd[(CTnd['Well Type'].ne("Spring"))]#.ne("Seep").ne("Cistern").ne("Creek").ne("Ditch").ne("Pond").ne("River").ne("Surface Water").ne("Tank"))]
    #CTNDS = CTnd[(CTnd['Well Type'].ne("Commercial"))]#.ne("Domestic Well").ne("Ground Water").ne("Groundwater").ne("Irrigation").ne("Monitoring Well").ne("Municipal").ne("Stock or  Irrigation").ne("Cistern").ne("Creek").ne("Ditch").ne("Pond").ne("River").ne("Surface Water").ne("Tank"))]

    outputs=[CTDW,CTDS,CTNDW,CTNDS]
    #remove columns with no values
    for t in outputs:
        for i in t.columns.tolist(): #for all columns
            try: #try to
                lnew=[] 
                l=t[i].tolist() #create a list of all values in a column
                for j in l:
                    if j == -99.9:
                        lnew.append(-100)
                    else:
                        lnew.append(0)
                avg=sum(lnew)/len(lnew) #take the average of those values
                if avg==-100: #find if the average is 
                    del t[i]
            except:
                pass


    ## Output data

    #put in csv using pandas, remove index to clean up
    CTDW.to_csv(r'outputFiles\CrossTabDetectsWellsCOGCC.csv',index=False)
    CTDS.to_csv(r'outputFiles\CrossTabDetectsSpringsCOGCC.csv',index=False)
    CTNDW.to_csv(r'outputFiles\CrossTabNonDetectsWellsCOGCC.csv',index=False)
    CTNDS.to_csv(r'outputFiles\CrossTabNonDetectsSpringsCOGCC.csv',index=False)
    broken = False
    break
