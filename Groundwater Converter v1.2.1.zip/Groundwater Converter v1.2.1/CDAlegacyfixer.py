import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import sys

ndi = pd.read_csv('inputFiles\\CDA\\actualnondetectsinorg.csv') #type in your input file for nondetect inorganics here
ndn = pd.read_csv('inputFiles\\CDA\\actualnondetectsno3.csv') #type in your input file for no3 inorganics here

ndict = pd.crosstab(ndi.WellID,ndi.Analyte,ndi.Result,aggfunc = 'max')
ndnct = pd.crosstab(ndn.WellID,ndn.Analyte,ndn.Result,aggfunc = 'max')

ndict.to_csv('inputFiles\\CDA\\actualnondetectsinorgct.csv') #type in your output file for nondetect inorganics which is now crosstabbed
ndnct.to_csv('inputFiles\\CDA\\actualnondetectsno3ct.csv') #type in your output file for nondetect no3 which is now crosstabbed
