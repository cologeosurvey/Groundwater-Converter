while True:
    try:
        import numpy as np
        import pandas as pd
        import os
        import sys
        from statistics import mode
        import time
        import traceback

        locwellscda = pd.read_csv('locwellscda.csv')

        # fileOne = 'inputFiles/CDA Inorganic Detect 07102025.csv'
        # fileTwo = 'inputFiles/CDA Inorganic Nondetect 07102025.csv'
        # extraFile1 = 'inputFiles/CDA Nutrients Detect 07102025.csv'
        # extraFile2 = 'inputFiles/CDA Nutrients Nondetect 07102025.csv'
        # extraFile3 = 'inputFiles/CDA Physical 07102025.csv'

        files = [fileOne, fileTwo, extraFile1, extraFile2, extraFile3]

        if all(f == "0" for f in files):
            print("Select the files from the browser")
            break
        elif any(f == "0" for f in files):
            print("Ensure all files are uploaded. All files have been cleared from memory so upload all five files again")
            break

        inorgd = inorgnd = NO3d = NO3nd = other = None

        for f in files:
            df = pd.read_csv(f).fillna(-99.9)
            cols = df.columns.tolist()

            if "Analyte Name" in cols:
                analytes = df["Analyte Name"].unique().tolist()
                if any("Nitrate" in a for a in analytes):
                    if "BDLIndicator" in df.columns and df["BDLIndicator"].eq(1).any():
                        NO3nd = f
                    else:
                        NO3d = f
                elif any("Copper" in a or "Cu -" in a for a in analytes):
                    if "BDLIndicator" in df.columns and df["BDLIndicator"].eq(1).any():
                        inorgnd = f
                    else:
                        inorgd = f
                elif any("pH" in a or "Conductance" in a for a in analytes):
                    other = f
            else:
                if "pH (Field)" in cols:
                    other = f
                elif "Nitrate as Nitrogen" in cols:
                    if (df["Nitrate as Nitrogen"] == 0).all():
                        NO3nd = f
                    else:
                        NO3d = f
                elif "Copper" in cols:
                    if (df["Copper"] == 0).all():
                        inorgnd = f
                    else:
                        inorgd = f

        for name, path in zip(['inorgd', 'inorgnd', 'NO3d', 'NO3nd', 'other'],
                              [inorgd, inorgnd, NO3d, NO3nd, other]):
            if path is None:
                raise FileNotFoundError(f"File for {name} is not assigned (None). Check that all input files were correctly classified.")

        print("Inorganic Detects:", inorgd)
        print("Inorganic Nondetects:", inorgnd)
        print("NO3 Detects:", NO3d)
        print("NO3 Nondetects:", NO3nd)
        print("Other:", other)

        dictFile = 'analytenames.csv'
        wellData = 'wellDataCDA.csv'
        WQPnd = 'outputFiles/CrossTabNonDetectsWellsWQP.csv'
        WQPd = 'outputFiles/CrossTabDetectsWellsWQP.csv'

        analytenames = pd.read_csv(dictFile)
        print("Analyte names imported")

        def drop_all_minus_99_9_columns(df):
            return df.loc[:, ~(df == -99.9).all()]

        def convert_ugL_to_mgL(df):
            if 'Unit' not in df.columns or 'Result' not in df.columns:
                return df
            df['Unit'] = df['Unit'].astype(str).str.strip().str.lower()
            for i, row in df.iterrows():
                if row['Unit'] == 'ug/l':
                    try:
                        df.at[i, 'Result'] = float(row['Result']) / 1000
                        df.at[i, 'Unit'] = 'mg/l'
                    except:
                        continue
            return df

        def load_and_standardize(file_path):
            df = pd.read_csv(file_path).fillna(-99.9)
            cols = df.columns.tolist()
            df = convert_ugL_to_mgL(df)

            if 'WellID' in df.columns:
                df.rename(columns={'WellID': 'Well ID'}, inplace=True)
            elif 'SiteName' in df.columns:
                df.rename(columns={'SiteName': 'Well ID'}, inplace=True)

            if 'Well ID' not in df.columns:
                raise ValueError(f"'Well ID' column missing in file: {file_path}")

            if "Analyte Name" in cols and "Result" in cols:
                df['Analyte Name'] = df['Analyte Name'].astype(str).str.strip()
                pivot_df = df.pivot_table(index='Well ID', columns='Analyte Name', values='Result', aggfunc='mean').reset_index()
                pivot_df.columns.name = None
                print(f"Pivoted {file_path}: {pivot_df.shape}")
                return pivot_df

            print(f"Loaded crosstab {file_path}: {df.shape}")
            return df

        def build_cda_outputs(inorgd, inorgnd, NO3d, NO3nd, other, analytenames_path, wqp_detects_path, wqp_nondetects_path):
            analytenames = pd.read_csv(analytenames_path)
            analytenames['cdaNames'] = analytenames['cdaNames'].str.strip().str.lower()
            analytenames['newNames'] = analytenames['newNames'].str.strip()
            analyte_map = dict(zip(analytenames['cdaNames'], analytenames['newNames']))

            def standardize_and_rename(fp):
                df = load_and_standardize(fp)
                df.columns = ['Well ID' if c.strip().lower() == 'well id' else c.strip().lower() for c in df.columns]
                df.rename(columns=analyte_map, inplace=True)
                return df

            df_inorgd = standardize_and_rename(inorgd)
            df_inorgnd = standardize_and_rename(inorgnd)
            df_NO3d = standardize_and_rename(NO3d)
            df_NO3nd = standardize_and_rename(NO3nd)
            df_other = standardize_and_rename(other)

            print("Pivoted Files Loaded")

            detects = pd.concat([df_inorgd, df_NO3d, df_other], axis=0, ignore_index=True).fillna(-99.9)
            nondetects = pd.concat([df_inorgnd, df_NO3nd, df_other], axis=0, ignore_index=True).fillna(-99.9)

            print("Detects & Nondetects sorted")

            detects = detects.drop_duplicates(subset=['Well ID'])
            nondetects = nondetects.drop_duplicates(subset=['Well ID'])

            wellData_df = pd.read_csv(wellData).fillna(-99.9)
            if 'WellCode' in wellData_df.columns:
                wellData_df.rename(columns={'WellCode': 'Well ID'}, inplace=True)
            if 'LATDDeg' in wellData_df.columns:
                wellData_df.rename(columns={'LATDDeg': 'Latitude'}, inplace=True)
            if 'LONDDeg' in wellData_df.columns:
                wellData_df.rename(columns={'LONDDeg': 'Longitude'}, inplace=True)

            if 'Latitude' in wellData_df.columns and 'Longitude' in wellData_df.columns:
                detects = pd.merge(detects, wellData_df[['Well ID', 'Latitude', 'Longitude']], on='Well ID', how='left')
                nondetects = pd.merge(nondetects, wellData_df[['Well ID', 'Latitude', 'Longitude']], on='Well ID', how='left')
                print("Well Data Added")
            else:
                print("Warning: Latitude or Longitude missing. Using placeholders.")
                detects['Latitude'] = -99.9
                detects['Longitude'] = -99.9
                nondetects['Latitude'] = -99.9
                nondetects['Longitude'] = -99.9

            new_dfs = []
            for df in [detects, nondetects]:
                df['Well Depth'] = 0
                df['Well Type'] = 'Well'

                cols = df.columns.tolist()
                for col in ['Latitude', 'Longitude', 'Well Depth', 'Well Type']:
                    if col in cols:
                        cols.remove(col)
                insert_at = cols.index('Well ID') + 1
                for idx, col in enumerate(['Latitude', 'Longitude', 'Well Depth', 'Well Type']):
                    cols.insert(insert_at + idx, col)
                df = df[cols].fillna(-99.99)
                new_dfs.append(drop_all_minus_99_9_columns(df))

            detects, nondetects = new_dfs

            print("Detects shape:", detects.shape)
            print("Nondetects shape:", nondetects.shape)

            os.makedirs('outputFiles', exist_ok=True)
            detects.to_csv('outputFiles/CrossTabDetectsWellsCDA.csv', index=False)
            nondetects.to_csv('outputFiles/CrossTabNonDetectsWellsCDA.csv', index=False)
            print("Exported CDA Detects and Nondetects.")

        build_cda_outputs(inorgd, inorgnd, NO3d, NO3nd, other, dictFile, WQPd, WQPnd)

    except Exception as e:
        print("Program failed in CDA conversion")
        traceback.print_exc()
        broken = True
        break

    broken = False
    break
